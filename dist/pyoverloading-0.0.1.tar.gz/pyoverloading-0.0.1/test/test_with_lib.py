import libtest
import libtest2


print(libtest.toto(1))
print(libtest.toto(1.1))

print(libtest2.toto(1))
print(libtest2.toto(False, 1, .2))