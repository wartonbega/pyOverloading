import pyOverloading.Overloading

VERSION = (0, 0, 1, "beta")
__version__ = '.'.join(VERSION)